﻿namespace PropertyLinkDemo.Models
{
    public class TextParserOptions
    {
        public bool IgnoreHeaderLine { get; set; }
        public bool IgnoreBlankLines { get; set; }
    }
}
